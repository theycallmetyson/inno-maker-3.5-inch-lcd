#setup capacitive touchscreen udev rules!
sudo cp ./95-ft6x06.rules /etc/udev/rules.d/
sudo cp ./95-ft6236.rules /etc/udev/rules.d/